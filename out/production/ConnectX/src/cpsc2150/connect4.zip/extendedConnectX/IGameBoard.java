package cpsc2150.extendedConnectX;

/**
 * Holds information about the GameBoard
 *
 * Defines: Player: 2 players
 *          Tokens: X and O
 *          Win: Marks the end of a game
 *          Tie: All grids completely filled with no winner
 *          Position: <r,c> location of where a token was dropped in c and stopped in r
 *
 * Initialization Ensures: a 2 -dimensional 6x9 GameBoard with position [0][0] on the bottom left of the board
 *                         and [5][8] on the top left of the board
 *
 * Constraints: 2 Players per game                                                                  &&
 *              Tokens: Either X or O                                                               &&
 *              Win = 5 tokens (all X or all O) in a row horizontally, vertically, or diagonally    &&
 *              Tie: No empty spaces in grid and no winner
 */
public interface IGameBoard {

    /**
     * This method returns the number of rows in the GameBoard
     *
     * @return: the number of rows in the GameBoard
     *
     * @post: getNumRows = rows
     */
    public int getNumRows();

    /**
     * This method returns the number of columns in the GameBoard
     *
     * @return number of columns in the GameBoard
     *
     * @post: getNumColumns = columns
     */
    public int getNumColumns();

    /**
     * This method returns the number of tokens in a row needed to win the game
     *
     * @return number of tokens in row needed to win
     *
     * @post: getNumToWin = numberOfTokensToWin
     */
    public int getNumToWin();

    /**
     * This method checks if columnPosition is a valid selection for a token
     *
     * @param columnPosition: the column where the token is to be placed
     *
     * @return true if column is able to accept another token, false if otherwise
     *
     * @pre: columnPosition < column
     *
     * @post: checkIfFree = true if token placed in [r,columnPosition] is empty
     */
    default public boolean checkIfFree(int columnPosition){
        for (int row = 0; row<getNumRows(); row++){
            BoardPosition pos = new BoardPosition(row,columnPosition);
            char boardInput = whatsAtPos(pos);
            if (boardInput == ' ') {
                return true;
            }
        }
        return false;
    }

    /**
     * This method checks if the last token placed is a win
     *
     * @param columnPosition: the column where the token was placed
     *
     * @return true if last token placed in columnPosition resulted in the player winning the game, false if otherwise
     *
     * @pre: columnPosition < column
     *
     * @post: checkForWin = true if token placed in [r,columnPosition] is the 5th same token in a row
     */
    default public boolean checkForWin(int columnPosition){
        int row;
        BoardPosition newPos = null;
// loops through column to find correct row that token was dropped into
        for (row = getNumRows()-1; row >= 0; row--){
            BoardPosition pos = new BoardPosition(row,columnPosition);
// if grid is not blank, it indicates correct row where token was placed
            if (isPlayerAtPos(pos,'X') || isPlayerAtPos(pos,'O')){
                newPos = new BoardPosition(row,columnPosition);
                break;
            }
        }
        return (checkDiagWin(newPos,'X')) || (checkDiagWin(newPos,'O')) ||
                checkHorizWin(newPos,'X') || checkHorizWin(newPos,'O') ||
                checkVertWin(newPos,'X') || checkVertWin(newPos,'O');
    }

    /**
     * This method checks for a tie
     *
     * @return true if GameBoard resulted in a tie, false otherwise
     *
     * @post: checkTie = true if all GameBoard grids not empty and no winner
     */
    default public boolean checkTie(){
        int counter=0;
        for (int i=0; i<getNumColumns(); i++){
            if (checkIfFree(i)==false){
                counter++;
            }
        }
        if (counter==40){
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method places a token onto the GameBoard
     *
     * @param token: the symbol for a player [X or O]
     * @param columnPosition: the column where the token is to be placed
     *
     * @pre: columnPosition < column && token = X or O
     *
     * @post: GameBoard = #GameBoard except token placed in [r,columnPosition]
     */
    public void placeToken(char token, int columnPosition);

    /**
     * This method checks to see if the last token placed resulted in a horizontal win
     *
     * @param pos: the position where a token was placed
     * @param player: the symbol for a player [X or O]
     *
     * @return true if the last token placed resulted in a horizontal win, false otherwise
     *
     * @post: checkHorizWin = true if pos results in 5 tokens in a row && GameBoard = #GameBoard
     */
    default public boolean checkHorizWin(BoardPosition pos, char player) {
        int counter;
        int i;
        int r = pos.getRow();
        int c = pos.getColumn();
        switch (player) {
            case 'X':
                counter = 0;
                i = 0;
                while (counter < getNumToWin()) {
                    // exceeding bounds
                    if (c+i >= getNumColumns()){
                        break;
                    }
                    BoardPosition posOne = new BoardPosition(r, c + i);
                    if (isPlayerAtPos(posOne, 'X') && c+i < getNumColumns() && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posOne, 'X')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                i = 1;
                while (counter < getNumToWin()) {
                    // exceeding bounds
                    if (c-i < 0){
                        break;
                    }
                    BoardPosition posTwo = new BoardPosition(r, c - i);
                    if (isPlayerAtPos(posTwo, 'X') && c-i >= 0 && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posTwo, 'X')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                if (counter >= getNumToWin()) {
                    return true;
                } else {
                    return false;
                }

            case 'O':
                counter = 0;
                i = 0;
                while (counter<getNumToWin()) {
                    // exceeding bounds
                    if ( c+i >= getNumColumns()){
                        break;
                    }
                    BoardPosition posOne = new BoardPosition(r, c + i);
                    if (isPlayerAtPos(posOne, 'O') && c+i < getNumColumns() && counter != getNumToWin()) {
                        counter++;
                        i++;
                    } else if (!isPlayerAtPos(posOne, 'O')) {
                        break;
                    } else if (counter == getNumToWin()){
                        return true;
                    }
                }
                i = 1;
                while (counter<getNumToWin()) {
                    // exceeding bounds
                    if (c-i < 0){
                        break;
                    }
                    BoardPosition posTwo = new BoardPosition(r, c - i);
                    if (isPlayerAtPos(posTwo, 'O') && c-i >= 0 && counter != getNumToWin()) {
                        counter++;
                        i++;
                    } else if (!isPlayerAtPos(posTwo, 'O')) {
                        break;
                    } else if (counter == getNumToWin()){
                        return true;
                    }
                }
                if (counter >= getNumToWin()){
                    return true;
                } else {
                    return false;
                }
        }
        return false;
    }

    /**
     * This method checks to see if the last token placed resulted in a vertical win
     *
     * @param pos: the position where a token was placed
     * @param player: the symbol for a player [X or O]
     *
     * @return true if the last token placed resulted in a vertical win, false otherwise
     *
     * @post: checkVertWin = true if pos resulted in 5 tokens in a row && GameBoard = #GameBoard
     */
    default public boolean checkVertWin(BoardPosition pos, char player){
        int counter;
        int i;
        int r = pos.getRow();
        int c = pos.getColumn();
        switch (player) {
            case 'X':
                counter = 0;
                i = 0;
                while (counter < getNumToWin()) {
                    // exceeding bounds
                    if (r+i >= getNumRows()){
                        break;
                    }
                    BoardPosition posOne = new BoardPosition(r+i, c);
                    if (isPlayerAtPos(posOne, 'X') && r+i < getNumRows() && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posOne, 'X')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                i = 1;
                while (counter < getNumToWin()) {
                    // exceeding bounds
                    if (r-i < 0){
                        break;
                    }
                    BoardPosition posTwo = new BoardPosition(r-i, c);
                    if (isPlayerAtPos(posTwo, 'X') && r-i >= 0 && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posTwo, 'X')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                if (counter >= getNumToWin()) {
                    return true;
                } else {
                    return false;
                }

            case 'O':
                counter = 0;
                i = 0;
                while (counter<getNumToWin()) {
                    // exceeding bounds
                    if (r+i >= getNumRows()){
                        break;
                    }
                    BoardPosition posOne = new BoardPosition(r+i, c);
                    if (isPlayerAtPos(posOne, 'O') && r+i < getNumRows() && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posOne, 'O')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                i = 1;
                while (counter<getNumToWin()) {
                    // exceeding bounds
                    if (r-i < 0){
                        break;
                    }
                    BoardPosition posTwo = new BoardPosition(r-i, c);
                    if (isPlayerAtPos(posTwo, 'O') && r-i >= 0 && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posTwo, 'O')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                if (counter>=getNumToWin()){
                    return true;
                } else {
                    return false;
                }
        }
        return false;
    }

    /**
     * This method checks to see if the last token placed resulted in diagonal win
     *
     * @param pos: the position where a token was placed
     * @param player: the symbol for a player [X or O]
     *
     * @return true if the last token placed in a diagonal win, false otherwise
     *
     * @post: checkDiagWin = true if pos resulted in 5 tokens in a row && GameBoard = #GameBoard
     */
    default public boolean checkDiagWin(BoardPosition pos, char player){
        int counter;
        int i;
        int r = pos.getRow();
        int c = pos.getColumn();
        switch (player) {
            case 'X':
                counter = 0;
                // diagonal of (+1,+1)
                i = 0;
                while (counter < getNumToWin()) {
                    // exceed bounds
                    if (r+i >= getNumRows() || c+i >= getNumColumns()){
                        break;
                    }
                    BoardPosition posOne = new BoardPosition(r+i, c+i);
                    if (isPlayerAtPos(posOne, 'X') && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                    if (!isPlayerAtPos(posOne, 'X')) {
                        break;
                    }
                }
                // diagonal of (-1,-1)
                i = 1;
                while (counter < getNumToWin()) {
                    // exceed bounds
                    if (r-i < 0 || c-i < 0){
                        break;
                    }
                    BoardPosition posTwo = new BoardPosition(r-i, c-i);
                    if (isPlayerAtPos(posTwo, 'X') && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posTwo, 'X')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                //diagonal of (+1,-1)
                i = 1;
                while (counter < getNumToWin()) {
                    // exceed bounds
                    if (r+i >= getNumRows() || c-i < 0){
                        break;
                    }
                    BoardPosition posTwo = new BoardPosition(r+i, c-i);
                    if (isPlayerAtPos(posTwo, 'X') && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posTwo, 'X')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                // diagonal of (-1,+1)
                i = 1;
                while (counter < getNumToWin()) {
                    // exceed bounds
                    if (r-i < 0 || c+i >= getNumColumns()){
                        break;
                    }
                    BoardPosition posTwo = new BoardPosition(r-i, c+i);
                    if (isPlayerAtPos(posTwo, 'X') && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posTwo, 'X')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                if (counter >= getNumToWin()) {
                    return true;
                } else {
                    return false;
                }

            case 'O':
                counter = 0;
                i = 0;
                while (counter<getNumToWin()) {
                    // exceed bounds
                    if (r+i >= getNumRows() || c+i >= getNumColumns()){
                        break;
                    }
                    BoardPosition posOne = new BoardPosition(r+i, c+i);
                    if (isPlayerAtPos(posOne, 'O') && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posOne, 'O')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                i = 1;
                while (counter<getNumToWin()) {
                    if (r-i < 0 || c-i < 0){
                        break;
                    }
                    BoardPosition posTwo = new BoardPosition(r-i, c-i);
                    if (isPlayerAtPos(posTwo, 'O') && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posTwo, 'O')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                //diagonal of (+1,-1)
                i = 1;
                while (counter < getNumToWin()) {
                    // exceed bounds
                    if (r+i >= getNumRows() || c-i < 0){
                        break;
                    }
                    BoardPosition posTwo = new BoardPosition(r+i, c-i);
                    if (isPlayerAtPos(posTwo, 'O') && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posTwo, 'O')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                // diagonal of (-1,+1)
                i = 1;
                while (counter < getNumToWin()) {
                    // exceed bounds
                    if (r-i < 0 || c+i >= getNumColumns()){
                        break;
                    }
                    BoardPosition posTwo = new BoardPosition(r-i, c+i);
                    if (isPlayerAtPos(posTwo, 'O') && counter != getNumToWin()) {
                        counter++;
                        i++;
                    }
                    if (!isPlayerAtPos(posTwo, 'O')) {
                        break;
                    }
                    if (counter == getNumToWin()){
                        return true;
                    }
                }
                if (counter>=getNumToWin()){
                    return true;
                } else {
                    return false;
                }
        }
        return false;
    }

    /**
     * This method checks what player is at a position
     *
     * @param pos: the position where a token was placed
     *
     * @return character of player that is in pos
     *
     * @pre: (0,0) <= pos <= (5,8)
     *
     * @post: GameBoard = #GameBoard
     */
    public char whatsAtPos(BoardPosition pos);

    /**
     * This method checks to see if a player is at a position
     *
     * @param pos: the position where a token was placed
     * @param player: the symbol for a player [X or O]
     *
     * @return true if the player is at pos, false otherwise
     *
     * @pre: (0,0) <= pos <= (5,8)
     *
     * @post: isPlayerAtPos = true if player is at pos
     */
    default public boolean isPlayerAtPos(BoardPosition pos, char player){
        return (whatsAtPos(pos) == player);
    }
}
