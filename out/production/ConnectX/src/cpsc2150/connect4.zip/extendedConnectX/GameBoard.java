package cpsc2150.extendedConnectX;

public class GameBoard extends AbsGameBoard implements IGameBoard {
    /**
     * @invariant: row = 6 && column = 9 && board = 6x9 2-dimensional array of char
     */
    private int row;
    private int column;
    private int numberOfTokensToWin;

    public GameBoard(){
        numberOfTokensToWin = 5;
        row = 6;
        column = 9;
        board = new char[row][column];
        // fills each grid of board with an empty space
        for (int i=0; i<row; i++){
            for (int j=0; j<column; j++){
                board[i][j] = ' ';
            }
        }
    }

    public int getNumRows(){ return row; }

    public int getNumColumns(){ return column; }

    public int getNumToWin(){ return numberOfTokensToWin; }

    public void placeToken(char token, int columnPosition){
        for (int i=0; i<row; i++){
            if (board[i][columnPosition]==' '){
                // places token into empty space
                board[i][columnPosition] = token;
                break;
            }
        }
    }

    public char whatsAtPos(BoardPosition pos){
       return board[pos.getRow()][pos.getColumn()];
    }
}
