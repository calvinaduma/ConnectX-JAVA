package cpsc2150.extendedConnectX;

public abstract class AbsGameBoard implements IGameBoard{

    protected char[][] board;
    /**
     * This method Overrides the toString() Object method to provide a string of the current GameBoard
     *
     * @return a string representation of the current GameBoard
     *
     * @post: toString() = string representation of the GameBoard
     */
    @Override
    public String toString(){
        String str = "";
        str = " | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | \n";
        for (int i=getNumRows()-1; i>=0; i--){
            for (int j=0; j<getNumColumns(); j++){
                str += " | " + board[i][j];
                if (j==getNumColumns()-1){
                    str += " | \n";
                }
            }
        }
        return str;
    }
}
