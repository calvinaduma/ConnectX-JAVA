package cpsc2150.extendedConnectX;

import java.util.*;

public class GameScreen {

    public static void main(String[] args){

// variable to control game flow
        boolean newGame = true;
        boolean continueGame;
        char[] playerTokens = {'X','O'};
        int column;
        char playAgain;
        String whiteSpace;
        String playerX = "Player X, what column do you want to place your marker in?\n";
        String playerO = "Player O, what column do you want to place your marker in?\n";
        String errorMessage = "The space is unavailable. Enter a new column.\n";
        Scanner input = new Scanner(System.in);
// start of new game
        while (newGame) {
            continueGame= true;
            IGameBoard game = new GameBoard();
            int turn = 0;
// start of player turns
            while (continueGame) {
                System.out.println(game.toString());
                char playerTurn = playerTokens[turn];
                switch (playerTurn) {
// Player X
                    case 'X':
                        System.out.println(playerX);
                        column = input.nextInt();
                        whiteSpace = input.nextLine(); // gets rid of white space after reading an int
// checks player X input
                        while (column < 0 || column >= game.getNumColumns() || !game.checkIfFree(column)) {
                            System.out.println(errorMessage);
                            column = input.nextInt();
                            whiteSpace = input.nextLine(); // gets rid of white space after reading an int
                        }
// passed check input
                        game.placeToken(playerTurn,column);
// checks for win
                        if (game.checkForWin(column)) {
                            System.out.println(game.toString());
                            System.out.println("Player X won!\nWould you like to play again? Y/N\n");
                            playAgain = input.nextLine().charAt(0);
// checks if players want to play again
                            boolean loop = true;
                            while (loop) {
                                if (playAgain == 'Y' || playAgain == 'N' || playAgain == 'n' || playAgain == 'y') {
                                    loop = false;
                                    break;
                                } else {
                                    System.out.println("Would you like to play again? Y/N\n");
                                    whiteSpace = input.nextLine(); // gets rid of white space after reading an int
                                    playAgain = input.nextLine().charAt(0);
                                }
                            }
// if play again, breaks out of case statement
                            if (playAgain == 'y' || playAgain == 'Y') {
                                continueGame = false;
                                break;
                            } else {
                                continueGame=false;
                                newGame=false;
                                break;
                            }
// if no win, turn is switched to 1 to signify player O turn
                        } else {
                            turn = 1;
                            break;
                        }
// Player O
                    case 'O':
                        System.out.println(playerO);
                        column = input.nextInt();
                        whiteSpace = input.nextLine(); // gets rid of white space after reading an int
// checks player O input
                        while (column < 0 || column >= game.getNumColumns() || !game.checkIfFree(column)) {
                            System.out.println(errorMessage);
                            column = input.nextInt();
                            whiteSpace = input.nextLine(); // gets rid of white space after reading an int
                        }
// passed check
                        game.placeToken(playerTurn,column);
// checks for win
                        if (game.checkForWin(column)){
                            System.out.println(game.toString());
                            System.out.println("Player O won!\nWould you like to play again? Y/N\n");
                            playAgain = input.nextLine().charAt(0);
// checks if players want to play again
                            boolean loop = true;
                            while (loop) {
                                if (playAgain == 'Y' || playAgain == 'N' || playAgain == 'n' || playAgain == 'y') {
                                    loop = false;
                                    break;
                                } else {
                                    System.out.println("Would you like to play again? Y/N\n");
                                    whiteSpace = input.nextLine(); // gets rid of white space after reading an int
                                    playAgain = input.nextLine().charAt(0);
                                }
                            }
// if play again, breaks out of case statement
                            if (playAgain == 'y' || playAgain == 'Y'){
                                continueGame = false;
                                break;
                            } else {
                                continueGame=false;
                                newGame=false;
                                break;
                            }
                        } else {
// if no win, turn is switched to 0 to signify player 1 turn
                            turn = 0;
                            break;
                        }
                }
            }
        }
    }

}
